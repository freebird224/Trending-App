package creativitycenter.com.hidden.model;

import com.google.gson.annotations.Expose;

public class Owner {
    @Expose
    private String login; //Le nom login du propriétaire du repositorie.
    @Expose
    private String avatar_url; // L'adresse url de l'avatare du proprietaire.

    //Contructeur sans paramètre de la classe Owner.
    public Owner() {
    }
    //Le constructeur avec paramètre de la classe Owner.
    public Owner(String login, String avatar_url)
    {
        this.login = login;
        this.avatar_url = avatar_url;
    }

    //La méthode qui récupère le nom login du propriétaire du repos.
    public String getLogin()
    {
        return login;
    }

    //La méthode qui modifie le nom login propriétaire.
    public void setLogin(String login)
    {
        this.login = login;
    }

    //La méthode qui récupère l'adresse url de l'avatare.
    public String getAvatar_url()
    {
        return avatar_url;
    }

    //La méthode qui modifie l'adresse url de l'avatare du propriétaire de repos.
    public void setAvatar_url(String avatar_url)
    {
        this.avatar_url = avatar_url;
    }
}
