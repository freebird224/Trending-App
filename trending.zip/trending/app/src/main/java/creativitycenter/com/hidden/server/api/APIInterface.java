package creativitycenter.com.hidden.server.api;

import creativitycenter.com.hidden.constants.Constants;
import creativitycenter.com.hidden.model.Repos;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface APIInterface {

    @GET(Constants.URL)
    Call<Repos> getRepos(@Query("q") String q , @Query("sort") String sort , @Query("order") String order , @Query("page") int page, @Query("per_page") int per_page );

}
