package creativitycenter.com.hidden.model;

import com.google.gson.annotations.Expose;

import java.util.ArrayList;

public class Repos{

    @Expose
    private long total_count ; // Le total des repositories
    @Expose
    private boolean incomplete_results; //L'attribut qui montre s'il ya des résultats incomplets.
    @Expose
    private ArrayList<Item> items; // La liste des repositories qui seront affichés.

    //Le contructeur sans paramètre de la classe Repos.
    public Repos() {
    }

    //Le contructeur avec paramètres de la classe Repos.
    public Repos(long total_count, boolean incomplete_results, ArrayList<Item> items)
    {
        this.total_count = total_count;
        this.incomplete_results = incomplete_results;
        this.items = items;
    }

    //La méthode qui retourne le total des repositories.
    public long getTotal_count()
    {
        return total_count;
    }
    //La méthode qui modifie le total des repositorie.
    public void setTotal_count(long total_count)
    {
        this.total_count = total_count;
    }
    //La méthode qui vérifie s'il ya des resultats incomplets.
    public boolean isIncomplete_results()
    {
        return incomplete_results;
    }
    //La méthode qui modifie s'il ya des resultats incomplets.
    public void setIncomplete_results(boolean incomplete_results) {
        this.incomplete_results = incomplete_results;
    }

    //La méthode qui récupère la liste des repositories à afficher.
    public ArrayList<Item> getItems()
    {
        return items;
    }
    //La méthode qui modifie la liste des repositories.
    public void setItems(ArrayList<Item> items) {
        this.items = items;
    }


}
