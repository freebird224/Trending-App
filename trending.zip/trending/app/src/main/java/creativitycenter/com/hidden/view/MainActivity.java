package creativitycenter.com.hidden.view;

import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;

import creativitycenter.com.hidden.R;

import static android.net.NetworkInfo.State.CONNECTED;

public class MainActivity extends AppCompatActivity {

    private ImageButton button_trending; //Le button permattant de passer sur la passe des repositories.
    private ImageButton button_settings; //Le button ppermttant de voir les pamètres de reglage.

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //La fonction d'Initialisation
        initialize();

        //
        button_trending.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                    //Ici on vérifie la connectivité de l'appareil
                    ConnectivityManager manager = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
                    NetworkInfo info = manager.getActiveNetworkInfo();
                    if(info != null){
                        //Si l'appareil est connecté on passe sur l'activité des repositories.
                        if(info.getState() == NetworkInfo.State.CONNECTED){
                            Intent intent = new Intent(MainActivity.this, ReposActivity.class);
                            startActivity(intent);
                        }
                    }
                    else
                    {
                        Toast.makeText(getApplicationContext(),R.string.error_connexion,Toast.LENGTH_LONG).show(); }

            }
        });

        button_settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"Ce button n'est pas programé !",Toast.LENGTH_LONG).show();
            }
        });



    }
    //Cette fonction permet de d'initialliser les objets qui seront utilisés.
    public void initialize(){
        button_trending = findViewById(R.id.btn_trending);
        button_settings = findViewById(R.id.btn_settings);

    }
}
