package creativitycenter.com.hidden.constants;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Constants {

    public static final String BASE_URL="https://api.github.com/";  //La base de url
    public  static final String URL="search/repositories";          //URL où sont stocker les Repositories
    public static final String DATE = "created:>"+getDateCreated(); //La date à partir de laquelle on doit afficher les Repos.
     public static final String SORT ="stars";                      //On trie sur le nombre d'étoile
     public static final String ORDER ="desc";                      //L'ordre affiche des repositories. Du plus grand au plus pétit.
     public static  int PAGE =1;                                    //C'est la constante qui permet de faire la pagination. 1 c'est la page par défaut.
     public static final int PER_PAGE = 100;                        //Le nombre de repos par page. Dans mon cas j'ai pris 100.

    //La méthode qui repère la date qui correspond au 30 derniers jour à partir de la date actuelle.
     public static String getDateCreated(){
         //On recupère la date actuelle.
         Date date = new Date();
         //On formate la date sous : yyyy-MM-dd;
         SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
         //On extrait l'année
         String annee = sdf.format(date).substring(0,4);
         //On extrait le mois.
         String mois = sdf.format(date).substring(5,7);
         //On extrait le jour
         String day = sdf.format(date).substring(8,10);
         //On convertit le mois en entier pour pouvoir le reduire.
         int mois_int = Integer.parseInt(mois);
         //On reduit le mois. ce qui veut dire que nous sommes dans les 30 derniers jours.
         mois_int --;
         //On reconertit le mois en String pour pouvoir le concaténé.
         mois = String.valueOf(mois_int);
         //On retourne la nouvelle date. qui correspond au 30 derniers jours.
         return annee+"-"+mois+"-"+day;
     }
}
