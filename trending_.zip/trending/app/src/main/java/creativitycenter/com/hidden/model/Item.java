package creativitycenter.com.hidden.model;


import com.google.gson.annotations.Expose;

public class Item {

    @Expose
    private String name; //le nom du repositories
    @Expose
    private String description; //La description du repositorie
    @Expose
    private long stargazers_count; //Le nombre d'étoiles du repositorie.
    @Expose
    private Owner owner; // Le proprietaire du repositories


    // Le constructeur sans paramètre de la classe Item
    public Item() {
    }

    // Le contructeur avec paramètre de la classe Item
    public Item(String name, String description, long stargazers_count, Owner owner) {
        this.name = name;
        this.description = description;
        this.stargazers_count = stargazers_count;
        this.owner = owner;
    }

    // La methode qui recupère le nom d'un repositorie.
    public String getName()
    {
        return name;
    }

    // La méthode qui modifie le nom d'un repositorie.
    public void setName(String name)
    {
        this.name = name;
    }

    // La méthode qui retourne la description d'un repositorie.
    public String getDescription()
    {
        return description;
    }

    // La méthode qui permet de modifier la description d'un object Repositorie.
    public void setDescription(String description)
    {
        this.description = description;
    }

    // La méthode qui permet de recupérer le nombre d'étoile d'un repositoirie.
    public long getStargazers_count() {
        return  stargazers_count;
    }

    //La méthode qui de modifier le nombre d'étoile d'un repositorie.
    public void setStargazers_count(long stargazers_count) {
        this.stargazers_count = stargazers_count;
    }

   // La méthode qui recupère le propriétaire d'un repositorie.
    public Owner getOwner()
    {
        return owner;
    }

    // La modifie le propriétaire d'un repositorie.
    public void setOwner(Owner owner)
    {
        this.owner = owner;
    }


}
