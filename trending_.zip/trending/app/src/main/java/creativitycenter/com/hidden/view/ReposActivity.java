package creativitycenter.com.hidden.view;


import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;


import creativitycenter.com.hidden.R;
import creativitycenter.com.hidden.adapters.RepoAdapter;
import creativitycenter.com.hidden.constants.Constants;
import creativitycenter.com.hidden.model.Item;
import creativitycenter.com.hidden.model.Repos;
import creativitycenter.com.hidden.server.api.APIInterface;
import creativitycenter.com.hidden.server.api.APIClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ReposActivity extends AppCompatActivity {

    private ListView listView;      //La liste qui sera utilisé pour afficher les Repos.
    private ImageButton btn_next;   //Le button qui d'aller sur la page suivante.
    private ImageButton btn_prev;   //Le button qui permet de se retourner la page précédente
    private ArrayList<Item> items;  //La liste des repositories
    private TextView pageNumber ;   //Le TextView qui permettra de connaitre la numéro de la page actuelle.
    private Button btn_first;       //Le Button qui permet d'aller sur la première page.
    private Button btn_last;        //Le button qui permet d'aller directement sur la dernière page.
    private Button home;            //Le button qui permet d'aller sur l'écran d'acceuil.
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_repos);

            //Initialisation
            initialize();
            //Affichage des Repos de la page par défaut : 1
            changePage(Constants.PAGE);

            btn_next.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Constants.PAGE ++;
                    changePage(Constants.PAGE);
                    pageNumber.setText(String.valueOf(Constants.PAGE)+"/10");
                }
            });

            btn_prev.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Constants.PAGE --;
                    changePage(Constants.PAGE);
                    pageNumber.setText(String.valueOf(Constants.PAGE)+"/10");

                }
            });

            btn_first.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Constants.PAGE = 1;
                    changePage(Constants.PAGE);
                    pageNumber.setText(String.valueOf(Constants.PAGE)+"/10");

                }
            });

            btn_last.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Constants.PAGE = 10;
                    changePage(Constants.PAGE);
                    pageNumber.setText(String.valueOf(Constants.PAGE)+"/10");
                }
            });

            home.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    finish();
                }
            });

        //Initialiaze



    }

 //La méthode qui permter d'afficher les items dans la liste en utilisant l'adapter
    public void afficher(ArrayList<Item> items, ListView listView){
        RepoAdapter adapter = new RepoAdapter(ReposActivity.this, items);
        listView.setAdapter(adapter);
    }

    //La méthode qui d'initialisation
    public void initialize(){
        listView    = findViewById(R.id.list);
        btn_next    = findViewById(R.id.button_next);
        btn_prev    = findViewById(R.id.button_prev);
        btn_first   = findViewById(R.id.first);
        btn_last    = findViewById(R.id.last);
        home        = findViewById(R.id.home);
        pageNumber  = findViewById(R.id.page);
        pageNumber.setText(String.valueOf(Constants.PAGE)+"/10");

    }

    //La méthode qui affiche les items d'une page donnée.
    public void changePage(int page  ){
        //Le nombre de page doit être positif.
        if(page < 1){
            page = 1;
        }
        /*Le nombre de page ne doit pas dépasse 10.
        Car on affiche sur chaque page 100 items et nous ne pouvons voir que les 1000 premiers reultats.
        Ce qui nous fait 1000/100 = 10 pages au total.
         */

        if(page >= 10){
            page =10;
        }

        ConnectivityManager manager = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        NetworkInfo info = manager.getActiveNetworkInfo();
        if(info != null){

            if(info.getState() == NetworkInfo.State.CONNECTED){
                Constants.PAGE = page;
                //Appel de IPI interface pour faire appel aux repositories.
                APIInterface apiInterface = APIClient.getClient().create(APIInterface.class);
                Call<Repos> call = apiInterface.getRepos(Constants.DATE , Constants.SORT , Constants.ORDER , Constants.PAGE, Constants.PER_PAGE);
                call.enqueue(new Callback<Repos>() {
                    @Override
                    public void onResponse(Call<Repos> call, Response<Repos> response) {
                        //S'il ya reponse on affiche le résultat dans la liste
                        if (response.body() != null) {
                            Repos result = (Repos) response.body();
                            items = result.getItems();
                            afficher(items,listView);

                        } else { //S'il n'ya pas de reponse on affiche le message suivant.
                            Toast.makeText(getApplicationContext(), "Une erreur s'est produite sur cette page.", Toast.LENGTH_LONG).show();
                        }

                    }
                    @Override //La méthode qui se déclenche en cas d'echec.
                    public void onFailure(Call<Repos> call, Throwable t) {
                        Toast.makeText(getApplicationContext(), "Une erreur s'est produite.", Toast.LENGTH_LONG).show();
                    }
                });

            }
            else {
                Toast.makeText(getApplicationContext(),R.string.error_connexion,Toast.LENGTH_LONG).show();
            }


        }
        else
        {
            Toast.makeText(getApplicationContext(),"Problème de connection ! \nVeuillez réessayer s'il vous plaît! ",Toast.LENGTH_LONG).show();
        }


    }




}
