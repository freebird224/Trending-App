package creativitycenter.com.hidden.adapters;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import creativitycenter.com.hidden.R;
import creativitycenter.com.hidden.model.Item;

public  class RepoAdapter extends BaseAdapter {


    private Activity activity;
    //La liste des repositories qui seront afficher dans la view
    private ArrayList<Item> items; //


    //Le contructeur de l'adapter
    public RepoAdapter(Activity activity, ArrayList<Item> items)
    {
        this.activity = activity;
        this.items = items;
    }

    //La méthode qui récupère le nombre de repositories dans la lsite.
    @Override
    public int getCount()
    {
        return items.size();
    }

    //La méthode qui recupère un Objet Item à une position donnée dans la liste.
    @Override
    public Object getItem(int position)
    {
        return items.get(position);
    }

    //La méthode qui récupère L'id d'un Object Item à une position donnée.
    @Override
    public long getItemId(int position)
    {
        return position;
    }

    //La méthode qui permet de permet de rélier un élément de la liste à la view.
    @Override
    public View getView(int position, View view, ViewGroup viewGroup)
    {
        LayoutInflater inflater = LayoutInflater.from(this.activity);

        if(inflater != null && view ==null)
            view = inflater.inflate(R.layout.list_item,viewGroup,false);


       //Recuparation des objets de la view list_item.xml avec l'id.
        TextView repoName           = (TextView) view.findViewById(R.id.repo_name);
        TextView repoDescription    = (TextView) view.findViewById(R.id.repo_description);
        TextView ownerName          = (TextView) view.findViewById(R.id.owner_name);
        TextView numberOfStar       =  (TextView) view.findViewById(R.id.number_of_star);
        ImageView ownerAvatar       = (ImageView) view.findViewById(R.id.owner_avatar);

        //Ici on relie un élément de la liste à les objets de la View listem.xml.
        Item item = (Item) items.get(position);
        repoName.setText(item.getName());
        repoDescription.setText(item.getDescription());
        repoDescription.setText(item.getDescription());
        ownerName.setText(item.getOwner().getLogin());

        /*Ici on formate l'affichage du nombre de star. si le nombre   atteint 1000 stars,
         on divise le nombre par 1000, on affiche la partie entiere + le premier chiffre de la partie entière + K
         Exemple : 13560 =>  13,5K
        */
        if( item.getStargazers_count() >= 1000 && item.getStargazers_count() < 1000000){
            double count = (double) item.getStargazers_count();
            count = count/1000;
            numberOfStar.setText(String.valueOf(count).substring(0,3)+"K");
        }
        else if(item.getStargazers_count() >= 1000000){
            //On fait le même formatage pour million
            double count = (double) item.getStargazers_count();
            count = count/1000000;
            numberOfStar.setText(String.valueOf(count).substring(0,3)+"M");
        }
        else
        {
            numberOfStar.setText(String.valueOf(item.getStargazers_count()));
        }
        //L'utilisation de Picasso pour récuperer l'avatare du propriétaire.
        Picasso.get().load(item.getOwner().getAvatar_url()).into(ownerAvatar);


        return view;
    }
}
